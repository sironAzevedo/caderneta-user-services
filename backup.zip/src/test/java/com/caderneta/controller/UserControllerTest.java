package com.caderneta.controller;

//@ExtendWith(SpringExtension.class)
//@WebMvcTest(controllers = UserController.class)
public class UserControllerTest {

//	@Autowired
//	private MockMvc mockMvc;
//
//	@Autowired
//	private ObjectMapper objectMapper;
//
//	@MockBean
//	private IUserService service;
//
//	@Test
//	void whenValidInput_thenReturns200() throws Exception {
//		mockMvc.perform(get("/v1/user/by-email")
//		        .contentType(MediaType.APPLICATION_JSON)
//		        .param("email", "email@test.com"))
//		        .andExpect(status().isOk());
//
//	}
//
//	@Test
//	void whenCreateUserValid_thenReturns200() throws Exception {
//		mockMvc.perform(post("/v1/user")
//		        .contentType(MediaType.APPLICATION_JSON)
//		        .content(objectMapper.writeValueAsString(UserCreate.createUser())))
//		        .andExpect(status().isOk());
//	}

}
