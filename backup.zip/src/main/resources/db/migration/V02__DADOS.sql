INSERT INTO TB_USER (NAME, EMAIL, PASSWORD, STATUS) VALUES ('Siron Azevedo', 'siron@fiap.com', '123456', 'ACTIVE');
INSERT INTO TB_USER (NAME, EMAIL, PASSWORD, STATUS) VALUES ('Anadson Passos', 'anadson@fiap.com', '123456', 'ACTIVE');
INSERT INTO TB_USER (NAME, EMAIL, PASSWORD, STATUS) VALUES ('Jhonatan Soares', 'jhonatan@fiap.com', '123456', 'ACTIVE');
INSERT INTO TB_USER (NAME, EMAIL, PASSWORD, STATUS) VALUES ('Nataly Ivonete', 'nataly@fiap.com', '123456', 'ACTIVE');
INSERT INTO TB_USER (NAME, EMAIL, PASSWORD, STATUS) VALUES ('Cliente da Silva', 'cliente@email.com', '123456', 'ACTIVE');