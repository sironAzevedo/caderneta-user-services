package com.caderneta.service.impl;

import com.caderneta.model.Role;
import com.caderneta.model.enums.PerfilEnum;
import com.caderneta.model.enums.UserStatusEnum;
import com.caderneta.repository.IRoleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.caderneta.handler.exception.UserException;
import com.caderneta.mapper.UserMapper;
import com.caderneta.model.User;
import com.caderneta.model.dto.LoginDTO;
import com.caderneta.model.dto.UserDTO;
import com.caderneta.repository.IUserRepository;
import com.caderneta.service.IUserService;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements IUserService {

	private final IUserRepository repo;
	private final IRoleRepository roleRepository;
	private final BCryptPasswordEncoder passwordEncoder;
	
	@Override
	public void create(UserDTO dto) {
		
		if (repo.existsByEmail(dto.getEmail())) {
			throw new UserException("Este e-mail já existe");
		}
		
		User user = UserMapper.INSTANCE.toEntity(dto);
		user.setPassword(passwordEncoder.encode(dto.getPassword()));
		List<Role> roles = roleRepository.findByName(PerfilEnum.ROLE_USER);
		user.setRoles(roles);
//		user.setStatus(UserStatusEnum.ACTIVE);
		repo.save(user);
	}

	@Override
	public UserDTO findByEmail(String email) {
		return repo.findByEmail(email).map(UserMapper.INSTANCE::toDTO).orElseThrow(() -> new UserException("Usuario não encontrado"));
	}

	@Override
	public void login(LoginDTO dto) {
		UserDTO user = this.findByEmail(dto.getEmail());
		
		if(!user.getPassword().equals(dto.getPassword())) {
			throw new UserException("Email e/ou senha estão incorretos");
		}
	}
}
