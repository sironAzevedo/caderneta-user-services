package com.caderneta.model.enums;

public enum UserStatusEnum {
	PENDING, ACTIVE, INACTIVE
}
