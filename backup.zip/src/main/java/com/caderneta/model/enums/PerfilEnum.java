package com.caderneta.model.enums;

public enum PerfilEnum {
    ROLE_ADMIN,
    ROLE_USER;
}
