package com.caderneta.repository;

import com.caderneta.model.Role;
import com.caderneta.model.enums.PerfilEnum;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IRoleRepository extends JpaRepository<Role, String> {

    List<Role> findByName(PerfilEnum perfil);
}
