#!/bin/sh

#echo 'Sleeping 50s...'
#sleep 50

echo 'Starting...'
java -jar caderneta-user-services.jar